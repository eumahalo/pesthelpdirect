import { Phone, Shield, Clock, Users, Leaf } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import heroImage from "@/assets/hero-technician.jpg";

const Index = () => {
  const phoneNumber = "tel:+18662285083";

  const trustIcons = [
    { icon: Shield, title: "Trusted Providers", description: "Reliable professionals" },
    { icon: Clock, title: "Fast Response Times", description: "Quick service connection" },
    { icon: Leaf, title: "Family & Pet Friendly", description: "Safe treatments" },
    { icon: Users, title: "Local Service Team", description: "Nearby experts" },
  ];

  const services = [
    "Ants",
    "Spiders",
    "Cockroaches",
    "House Crickets",
    "Mice",
    "Rats",
    "Earwigs",
    "Silverfish",
    "Clothes Moths",
    "Centipedes",
    "Millipedes",
    "Termites",
  ];

  const steps = [
    { number: "1", title: "Tap to call our dispatch line", description: "Quick and easy connection" },
    { number: "2", title: "Briefly describe your issue", description: "Tell us what you need" },
    { number: "3", title: "Get connected with a local professional", description: "Fast service setup" },
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-b from-accent to-background">
        <div className="container mx-auto px-4 py-16 md:py-24">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="text-center lg:text-left">
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-foreground mb-6 leading-tight">
                Fast, Professional Pest Control — Call Now
              </h1>
              <p className="text-xl md:text-2xl text-muted-foreground mb-8">
                Connect instantly with reliable local providers.
              </p>
              <a href={phoneNumber} className="inline-block">
                <Button variant="cta" size="xl" className="w-full sm:w-auto">
                  <Phone className="mr-2 h-5 w-5" />
                  Call Now for Immediate Help
                </Button>
              </a>
            </div>
            <div className="relative">
              <img
                src={heroImage}
                alt="Professional pest control technician"
                className="rounded-lg shadow-2xl w-full h-auto"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Trust Icons Section */}
      <section className="py-16 bg-background">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {trustIcons.map((item, index) => (
              <Card key={index} className="p-6 text-center hover:shadow-lg transition-shadow">
                <div className="flex justify-center mb-4">
                  <div className="w-16 h-16 rounded-full bg-accent flex items-center justify-center">
                    <item.icon className="h-8 w-8 text-primary" />
                  </div>
                </div>
                <h3 className="font-semibold text-lg mb-2 text-foreground">{item.title}</h3>
                <p className="text-muted-foreground text-sm">{item.description}</p>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-16 bg-secondary">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
              Professional Help for Common Pest Issues
            </h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              Our network of providers handles a wide range of household pest concerns.
            </p>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4 mb-12">
            {services.map((service, index) => (
              <Card key={index} className="p-4 text-center hover:shadow-md transition-shadow">
                <p className="font-medium text-foreground">{service}</p>
              </Card>
            ))}
          </div>
          <div className="text-center">
            <a href={phoneNumber}>
              <Button variant="cta" size="lg">
                <Phone className="mr-2 h-5 w-5" />
                Call for Expert Help
              </Button>
            </a>
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="py-16 bg-background">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
              How Our Service Works
            </h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto mb-12">
            {steps.map((step, index) => (
              <div key={index} className="text-center">
                <div className="w-16 h-16 rounded-full bg-primary text-primary-foreground font-bold text-2xl flex items-center justify-center mx-auto mb-4">
                  {step.number}
                </div>
                <h3 className="font-semibold text-xl mb-2 text-foreground">{step.title}</h3>
                <p className="text-muted-foreground">{step.description}</p>
              </div>
            ))}
          </div>
          <div className="text-center">
            <a href={phoneNumber}>
              <Button variant="cta" size="lg">
                <Phone className="mr-2 h-5 w-5" />
                Call a Technician Now
              </Button>
            </a>
          </div>
        </div>
      </section>

      {/* Final CTA Section */}
      <section className="py-20 bg-gradient-to-b from-accent to-secondary">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-5xl font-bold text-foreground mb-6">
            Ready to Solve Your Pest Problem?
          </h2>
          <p className="text-xl md:text-2xl text-muted-foreground mb-8 max-w-2xl mx-auto">
            Providers are available to assist you today.
          </p>
          <a href={phoneNumber}>
            <Button variant="cta" size="xl">
              <Phone className="mr-2 h-6 w-6" />
              Call Now — Available Today
            </Button>
          </a>
        </div>
      </section>

      {/* Footer with Disclaimer */}
      <footer className="py-12 bg-muted">
        <div className="container mx-auto px-4">
          <div className="text-center mb-8">
            <a href={phoneNumber}>
              <Button variant="cta" size="lg">
                <Phone className="mr-2 h-5 w-5" />
                Call Now
              </Button>
            </a>
          </div>
          <div className="text-xs text-muted-foreground leading-relaxed max-w-4xl mx-auto">
            <p>
              <strong>Disclaimer:</strong> This site is a free service to assist homeowners in connecting
              with local service providers. All contractors/providers are independent and this site does
              not warrant or guarantee any work performed. It is the responsibility of the homeowner to
              verify that the hired contractor furnishes the necessary license and insurance required for
              the work being performed. All persons depicted in a photo or video are actors or models and
              not contractors listed on this site.
            </p>
          </div>
        </div>
      </footer>

      {/* Mobile Sticky CTA */}
      <div className="fixed bottom-0 left-0 right-0 p-4 bg-background border-t border-border shadow-lg lg:hidden z-50">
        <a href={phoneNumber} className="block">
          <Button variant="cta" size="lg" className="w-full">
            <Phone className="mr-2 h-5 w-5" />
            Call Now
          </Button>
        </a>
      </div>
    </div>
  );
};

export default Index;
