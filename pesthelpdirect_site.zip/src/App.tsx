
import React from 'react';
import Index from './pages/Index';
import './styles.css';
export default function App(){ return <Index />; }
